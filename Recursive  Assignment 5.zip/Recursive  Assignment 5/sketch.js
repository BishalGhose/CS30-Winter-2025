// Recursion Assignment
// Bishal Ghose

// Starting Seed
let seed = 1;

function setup() {
  createCanvas(windowWidth, windowHeight);
}

// Calls the recursive electricity and sets the background, seed, stroke, strokeweight
function draw() {
  background(0);
  stroke(0, 255, 255, 255);
  strokeWeight(5);
  randomSeed(seed);
  recursiveElectricity(width/2, height/2, 10, 250, 6, 255);
}


function recursiveElectricity(x, y, depth, len, weight, transparency) {
  if (depth === 0){ // Finishes once depth hits 0
    return;
  }

  stroke(0, 200, 255, transparency); 
  strokeWeight(weight);

  // Makes 2-4 random branches
  for (let i = 1; i <= Math.floor(random(2,4)); i ++){
    // Sets a random direction then finds the x and y
    let randomDirection = random(0, 2 * Math.PI);
    let finalX = x + cos(randomDirection) * len;
    let finalY = y + sin(randomDirection) * len;

    line(x, y, finalX, finalY); // Draws it

    recursiveElectricity(finalX, finalY, depth - 1, len * random(0.8, 0.9), weight  * random(0.8, 0.9), transparency  * random(0.7, 0.9)); // Recursive call
  }
}

// Changes seed every time mouse is pressed
function mouseClicked(){
  seed += 1;
}